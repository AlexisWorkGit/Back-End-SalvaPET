
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_id` bigint(20) unsigned DEFAULT NULL,
  `causer_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_id` bigint(20) unsigned DEFAULT NULL,
  `properties` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject` (`subject_type`,`subject_id`),
  KEY `causer` (`causer_type`,`causer_id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,'default','Setting was updated','App\\Models\\Setting',1,'App\\Models\\User',1,'[]','2021-10-16 03:37:44','2021-10-16 03:37:44');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `animals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `animals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `animals` WRITE;
/*!40000 ALTER TABLE `animals` DISABLE KEYS */;
/*!40000 ALTER TABLE `animals` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `antibiotics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `antibiotics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shortcut` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commercial_name` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `antibiotics` WRITE;
/*!40000 ALTER TABLE `antibiotics` DISABLE KEYS */;
/*!40000 ALTER TABLE `antibiotics` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lat` double(8,2) DEFAULT NULL,
  `lng` double(8,2) DEFAULT NULL,
  `zoom_level` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `chats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chats` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `from` int(10) unsigned DEFAULT NULL,
  `to` int(10) unsigned DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `chats` WRITE;
/*!40000 ALTER TABLE `chats` DISABLE KEYS */;
/*!40000 ALTER TABLE `chats` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contracts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount` double(8,2) unsigned NOT NULL DEFAULT 0.00,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contracts` WRITE;
/*!40000 ALTER TABLE `contracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contracts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `culture_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `culture_options` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `culture_options` WRITE;
/*!40000 ALTER TABLE `culture_options` DISABLE KEYS */;
INSERT INTO `culture_options` VALUES (1,'Organism',0,NULL,NULL,NULL),(2,'Colony Count',0,NULL,NULL,NULL),(3,'Condition',0,NULL,NULL,NULL),(4,'opt 1',1,NULL,NULL,NULL),(5,'opt 2',1,NULL,NULL,NULL),(6,'opt 1',2,NULL,NULL,NULL),(7,'opt 2',2,NULL,NULL,NULL),(8,'opt 1',3,NULL,NULL,NULL),(9,'opt 2',3,NULL,NULL,NULL);
/*!40000 ALTER TABLE `culture_options` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cultures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cultures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sample_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `precautions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` double DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cultures` WRITE;
/*!40000 ALTER TABLE `cultures` DISABLE KEYS */;
INSERT INTO `cultures` VALUES (1,'Blood Culture',NULL,NULL,100,NULL,'2021-10-16 02:23:57','2021-10-16 02:23:57');
/*!40000 ALTER TABLE `cultures` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currencies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `iso` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `symbol` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=165 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` VALUES (1,'AED','United Arab Emirates Dirham','د.إ'),(2,'AFN','Afghan Afghani','؋'),(3,'ALL','Albanian Lek','L'),(4,'AMD','Armenian Dram','դր.'),(5,'ANG','Netherlands Antillean Gulden','ƒ'),(6,'AOA','Angolan Kwanza','Kz'),(7,'ARS','Argentine Peso','$'),(8,'AUD','Australian Dollar','$'),(9,'AWG','Aruban Florin','ƒ'),(10,'AZN','Azerbaijani Manat','null'),(11,'BAM','Bosnia and Herzegovina Convertible Mark','КМ'),(12,'BBD','Barbadian Dollar','$'),(13,'BDT','Bangladeshi Taka','৳'),(14,'BGN','Bulgarian Lev','лв'),(15,'BHD','Bahraini Dinar','ب.د'),(16,'BIF','Burundian Franc','Fr'),(17,'BMD','Bermudian Dollar','$'),(18,'BND','Brunei Dollar','$'),(19,'BOB','Bolivian Boliviano','Bs.'),(20,'BRL','Brazilian Real','R$'),(21,'BSD','Bahamian Dollar','$'),(22,'BTN','Bhutanese Ngultrum','Nu.'),(23,'BWP','Botswana Pula','P'),(24,'BYR','Belarusian Ruble','Br'),(25,'BZD','Belize Dollar','$'),(26,'CAD','Canadian Dollar','$'),(27,'CDF','Congolese Franc','Fr'),(28,'CHF','Swiss Franc','Fr'),(29,'CLF','Unidad de Fomento','UF'),(30,'CLP','Chilean Peso','$'),(31,'CNY','Chinese Renminbi Yuan','¥'),(32,'COP','Colombian Peso','$'),(33,'CRC','Costa Rican Colón','₡'),(34,'CUC','Cuban Convertible Peso','$'),(35,'CUP','Cuban Peso','$'),(36,'CVE','Cape Verdean Escudo','$'),(37,'CZK','Czech Koruna','Kč'),(38,'DJF','Djiboutian Franc','Fdj'),(39,'DKK','Danish Krone','kr'),(40,'DOP','Dominican Peso','$'),(41,'DZD','Algerian Dinar','د.ج'),(42,'EGP','Egyptian Pound','ج.م'),(43,'ERN','Eritrean Nakfa','Nfk'),(44,'ETB','Ethiopian Birr','Br'),(45,'EUR','Euro','€'),(46,'FJD','Fijian Dollar','$'),(47,'FKP','Falkland Pound','£'),(48,'GBP','British Pound','£'),(49,'GEL','Georgian Lari','ლ'),(50,'GHS','Ghanaian Cedi','₵'),(51,'GIP','Gibraltar Pound','£'),(52,'GMD','Gambian Dalasi','D'),(53,'GNF','Guinean Franc','Fr'),(54,'GTQ','Guatemalan Quetzal','Q'),(55,'GYD','Guyanese Dollar','$'),(56,'HKD','Hong Kong Dollar','$'),(57,'HNL','Honduran Lempira','L'),(58,'HRK','Croatian Kuna','kn'),(59,'HTG','Haitian Gourde','G'),(60,'HUF','Hungarian Forint','Ft'),(61,'IDR','Indonesian Rupiah','Rp'),(62,'ILS','Israeli New Sheqel','₪'),(63,'INR','Indian Rupee','₹'),(64,'IQD','Iraqi Dinar','ع.د'),(65,'IRR','Iranian Rial','﷼'),(66,'ISK','Icelandic Króna','kr'),(67,'JMD','Jamaican Dollar','$'),(68,'JOD','Jordanian Dinar','د.ا'),(69,'JPY','Japanese Yen','¥'),(70,'KES','Kenyan Shilling','KSh'),(71,'KGS','Kyrgyzstani Som','som'),(72,'KHR','Cambodian Riel','៛'),(73,'KMF','Comorian Franc','Fr'),(74,'KPW','North Korean Won','₩'),(75,'KRW','South Korean Won','₩'),(76,'KWD','Kuwaiti Dinar','د.ك'),(77,'KYD','Cayman Islands Dollar','$'),(78,'KZT','Kazakhstani Tenge','〒'),(79,'LAK','Lao Kip','₭'),(80,'LBP','Lebanese Pound','ل.ل'),(81,'LKR','Sri Lankan Rupee','₨'),(82,'LRD','Liberian Dollar','$'),(83,'LSL','Lesotho Loti','L'),(84,'LTL','Lithuanian Litas','Lt'),(85,'LVL','Latvian Lats','Ls'),(86,'LYD','Libyan Dinar','ل.د'),(87,'MAD','Moroccan Dirham','د.م.'),(88,'MDL','Moldovan Leu','L'),(89,'MGA','Malagasy Ariary','Ar'),(90,'MKD','Macedonian Denar','ден'),(91,'MMK','Myanmar Kyat','K'),(92,'MNT','Mongolian Tögrög','₮'),(93,'MOP','Macanese Pataca','P'),(94,'MRO','Mauritanian Ouguiya','UM'),(95,'MUR','Mauritian Rupee','₨'),(96,'MVR','Maldivian Rufiyaa','MVR'),(97,'MWK','Malawian Kwacha','MK'),(98,'MXN','Mexican Peso','$'),(99,'MYR','Malaysian Ringgit','RM'),(100,'MZN','Mozambican Metical','MTn'),(101,'NAD','Namibian Dollar','$'),(102,'NGN','Nigerian Naira','₦'),(103,'NIO','Nicaraguan Córdoba','C$'),(104,'NOK','Norwegian Krone','kr'),(105,'NPR','Nepalese Rupee','₨'),(106,'NZD','New Zealand Dollar','$'),(107,'OMR','Omani Rial','ر.ع.'),(108,'PAB','Panamanian Balboa','B/.'),(109,'PEN','Peruvian Nuevo Sol','S/.'),(110,'PGK','Papua New Guinean Kina','K'),(111,'PHP','Philippine Peso','₱'),(112,'PKR','Pakistani Rupee','₨'),(113,'PLN','Polish Złoty','zł'),(114,'PYG','Paraguayan Guaraní','₲'),(115,'QAR','Qatari Riyal','ر.ق'),(116,'RON','Romanian Leu','Lei'),(117,'RSD','Serbian Dinar','РСД'),(118,'RUB','Russian Ruble','р.'),(119,'RWF','Rwandan Franc','FRw'),(120,'SAR','Saudi Riyal','ر.س'),(121,'SBD','Solomon Islands Dollar','$'),(122,'SCR','Seychellois Rupee','₨'),(123,'SDG','Sudanese Pound','£'),(124,'SEK','Swedish Krona','kr'),(125,'SGD','Singapore Dollar','$'),(126,'SHP','Saint Helenian Pound','£'),(127,'SKK','Slovak Koruna','Sk'),(128,'SLL','Sierra Leonean Leone','Le'),(129,'SOS','Somali Shilling','Sh'),(130,'SRD','Surinamese Dollar','$'),(131,'SSP','South Sudanese Pound','£'),(132,'STD','São Tomé and Príncipe Dobra','Db'),(133,'SVC','Salvadoran Colón','₡'),(134,'SYP','Syrian Pound','£S'),(135,'SZL','Swazi Lilangeni','L'),(136,'THB','Thai Baht','฿'),(137,'TJS','Tajikistani Somoni','ЅМ'),(138,'TMT','Turkmenistani Manat','T'),(139,'TND','Tunisian Dinar','د.ت'),(140,'TOP','Tongan Paʻanga','T$'),(141,'TRY','Turkish Lira','TL'),(142,'TTD','Trinidad and Tobago Dollar','$'),(143,'TWD','New Taiwan Dollar','$'),(144,'TZS','Tanzanian Shilling','Sh'),(145,'UAH','Ukrainian Hryvnia','₴'),(146,'UGX','Ugandan Shilling','USh'),(147,'USD','United States Dollar','$'),(148,'UYU','Uruguayan Peso','$'),(149,'UZS','Uzbekistani Som','null'),(150,'VEF','Venezuelan Bolívar','Bs F'),(151,'VND','Vietnamese Đồng','₫'),(152,'VUV','Vanuatu Vatu','Vt'),(153,'WST','Samoan Tala','T'),(154,'XAF','Central African Cfa Franc','Fr'),(155,'XAG','Silver (Troy Ounce)','oz t'),(156,'XAU','Gold (Troy Ounce)','oz t'),(157,'XCD','East Caribbean Dollar','$'),(158,'XDR','Special Drawing Rights','SDR'),(159,'XOF','West African Cfa Franc','Fr'),(160,'XPF','Cfp Franc','Fr'),(161,'YER','Yemeni Rial','﷼'),(162,'ZAR','South African Rand','R'),(163,'ZMK','Zambian Kwacha','ZK'),(164,'ZMW','Zambian Kwacha','ZK');
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `doctors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `commission` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `doctors` WRITE;
/*!40000 ALTER TABLE `doctors` DISABLE KEYS */;
/*!40000 ALTER TABLE `doctors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expense_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `expense_categories` WRITE;
/*!40000 ALTER TABLE `expense_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `expense_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `expense_category_id` int(11) DEFAULT NULL,
  `amount` double NOT NULL DEFAULT 0,
  `date` date DEFAULT NULL,
  `notes` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `group_culture_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_culture_options` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_culture_id` int(11) DEFAULT NULL,
  `culture_option_id` int(11) DEFAULT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `group_culture_options` WRITE;
/*!40000 ALTER TABLE `group_culture_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_culture_options` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `group_culture_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_culture_results` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_culture_id` int(11) DEFAULT NULL,
  `antibiotic_id` int(11) DEFAULT NULL,
  `sensitivity` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `group_culture_results` WRITE;
/*!40000 ALTER TABLE `group_culture_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_culture_results` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `group_cultures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_cultures` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL,
  `culture_id` int(11) DEFAULT NULL,
  `price` double(8,2) DEFAULT NULL,
  `done` tinyint(1) NOT NULL DEFAULT 0,
  `comment` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `group_cultures` WRITE;
/*!40000 ALTER TABLE `group_cultures` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_cultures` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `group_test_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_test_results` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_test_id` int(11) DEFAULT NULL,
  `test_id` int(11) DEFAULT NULL,
  `result` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `group_test_results` WRITE;
/*!40000 ALTER TABLE `group_test_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_test_results` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `group_tests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_tests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL,
  `test_id` int(11) DEFAULT NULL,
  `price` double(8,2) DEFAULT NULL,
  `has_results` tinyint(1) NOT NULL DEFAULT 0,
  `has_entered` tinyint(1) NOT NULL DEFAULT 0,
  `done` tinyint(1) NOT NULL DEFAULT 0,
  `comment` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `group_tests` WRITE;
/*!40000 ALTER TABLE `group_tests` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_tests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `barcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branch_id` int(10) unsigned DEFAULT NULL,
  `animal_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `contract_id` int(11) DEFAULT NULL,
  `discount` double(8,2) NOT NULL DEFAULT 0.00,
  `subtotal` double(8,2) NOT NULL DEFAULT 0.00,
  `total` double(8,2) NOT NULL DEFAULT 0.00,
  `paid` double(8,2) NOT NULL DEFAULT 0.00,
  `due` double(8,2) NOT NULL DEFAULT 0.00,
  `done` tinyint(1) NOT NULL DEFAULT 0,
  `doctor_commission` double(8,2) NOT NULL DEFAULT 0.00,
  `signature` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `report_pdf` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receipt_pdf` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `iso` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `rtl` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2016_06_01_000001_create_oauth_auth_codes_table',1),(2,'2016_06_01_000002_create_oauth_access_tokens_table',1),(3,'2016_06_01_000003_create_oauth_refresh_tokens_table',1),(4,'2016_06_01_000004_create_oauth_clients_table',1),(5,'2016_06_01_000005_create_oauth_personal_access_clients_table',1),(6,'2020_06_291_023147_create_animals_table',1),(7,'2020_06_29_0231471_create_group_tests_table',1),(8,'2020_06_29_0231471_create_groups_table',1),(9,'2020_06_29_023147_create_antibiotics_table',1),(10,'2020_06_29_023147_create_cultures_table',1),(11,'2020_06_29_023147_create_currencies_table',1),(12,'2020_06_29_023147_create_doctors_table',1),(13,'2020_06_29_023147_create_failed_jobs_table',1),(14,'2020_06_29_023147_create_group_culture_results_table',1),(15,'2020_06_29_023147_create_group_cultures_table',1),(16,'2020_06_29_023147_create_group_test_results_table',1),(17,'2020_06_29_023147_create_password_resets_table',1),(18,'2020_06_29_023147_create_permissions_table',1),(19,'2020_06_29_023147_create_role_permissions_table',1),(20,'2020_06_29_023147_create_roles_table',1),(21,'2020_06_29_023147_create_settings_table',1),(22,'2020_06_29_023147_create_user_roles_table',1),(23,'2020_06_29_023147_create_users_table',1),(24,'2020_07_14_164944_create_chats_table',1),(25,'2020_07_19_0402311212_create_visits_table',1),(26,'2020_07_23_00134911_create_branches_table',1),(27,'2020_07_25_0846441_create_contracts_table',1),(28,'2020_07_26_174857_create_expenses_table',1),(29,'2020_07_26_180427_create_expense_categories_table',1),(30,'2020_09_19_01584112_create_component_options_table',1),(31,'2020_09_21_081815_create_tests_table',1),(32,'2020_09_21_090444_create_culture_options_table',1),(33,'2020_09_22_000304_create_activity_log_table',1),(34,'2020_09_23_06421111_create_group_culture_options',1),(35,'2020_09_28_005305_create_modules_table',1),(36,'2020_10_13_163657_create_languages_table',1),(37,'2021_01_07_055724_add_direction_to_languages_table',1),(38,'2021_03_12_112340_add_commission_to_doctors',1),(39,'2021_03_12_121735_add_doctor_id_to_expenses_table',1),(40,'2021_03_13_032624_add_code_to_doctors_table',1),(41,'2021_03_13_175226_add_signature_to_users_table',1),(42,'2021_08_27_080016_create_owners_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
INSERT INTO `modules` VALUES (1,'tests','2021-10-16 02:23:56','2021-10-16 02:23:56'),(2,'cultures','2021-10-16 02:23:56','2021-10-16 02:23:56'),(3,'antibiotics','2021-10-16 02:23:56','2021-10-16 02:23:56'),(4,'culture options','2021-10-16 02:23:56','2021-10-16 02:23:56'),(5,'doctors','2021-10-16 02:23:56','2021-10-16 02:23:56'),(6,'groups tests','2021-10-16 02:23:56','2021-10-16 02:23:56'),(7,'Animal Owners','2021-10-16 02:23:56','2021-10-16 02:23:56'),(8,'Animals','2021-10-16 02:23:56','2021-10-16 02:23:56'),(9,'tests reports','2021-10-16 02:23:56','2021-10-16 02:23:56'),(10,'roles','2021-10-16 02:23:56','2021-10-16 02:23:56'),(11,'users','2021-10-16 02:23:56','2021-10-16 02:23:56'),(12,'price list','2021-10-16 02:23:56','2021-10-16 02:23:56'),(13,'accounting reports','2021-10-16 02:23:56','2021-10-16 02:23:56'),(14,'Home visits','2021-10-16 02:23:56','2021-10-16 02:23:56'),(15,'Branches','2021-10-16 02:23:56','2021-10-16 02:23:56'),(16,'contracts','2021-10-16 02:23:56','2021-10-16 02:23:56'),(17,'expense categories','2021-10-16 02:23:56','2021-10-16 02:23:56'),(18,'Expenses','2021-10-16 02:23:57','2021-10-16 02:23:57'),(19,'Backups','2021-10-16 02:23:57','2021-10-16 02:23:57'),(20,'setting','2021-10-16 02:23:57','2021-10-16 02:23:57'),(21,'Chat','2021-10-16 02:23:57','2021-10-16 02:23:57'),(22,'Actvity logs','2021-10-16 02:23:57','2021-10-16 02:23:57'),(23,'Translation','2021-10-16 02:23:57','2021-10-16 02:23:57');
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
INSERT INTO `oauth_clients` VALUES (1,NULL,'lab Personal Access Client','5nsRZv0wYhq4CZI8JQm6lUdphJckEJo3hHizzuqU',NULL,'http://localhost',1,0,0,'2021-10-16 02:23:59','2021-10-16 02:23:59'),(2,NULL,'lab Password Grant Client','gJnK5aZ865vWqXzpO3w3uW5Sml1CLhL5c85QXQOS','users','http://localhost',0,1,0,'2021-10-16 02:23:59','2021-10-16 02:23:59'),(3,NULL,'lab Personal Access Client','6zfJxewa6bPCEA1dEGmws4qElTK7GHwygiSuWgjG',NULL,'http://localhost',1,0,0,'2021-10-16 02:23:59','2021-10-16 02:23:59'),(4,NULL,'lab Password Grant Client','pe1xgdaJSaxKIvltbRCh5OzZssWR2bg3CCZbUPkC','users','http://localhost',0,1,0,'2021-10-16 02:23:59','2021-10-16 02:23:59');
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
INSERT INTO `oauth_personal_access_clients` VALUES (1,1,'2021-10-16 02:23:59','2021-10-16 02:23:59'),(2,3,'2021-10-16 02:23:59','2021-10-16 02:23:59');
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `owners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `owners` WRITE;
/*!40000 ALTER TABLE `owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `owners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,1,'View','view_test',NULL,NULL),(2,1,'Create','create_test',NULL,NULL),(3,1,'Edit','edit_test',NULL,NULL),(4,1,'Delete','delete_test',NULL,NULL),(5,2,'View','view_culture',NULL,NULL),(6,2,'Create','create_culture',NULL,NULL),(7,2,'Edit','edit_culture',NULL,NULL),(8,2,'Delete','delete_culture',NULL,NULL),(9,3,'View','view_antibiotic',NULL,NULL),(10,3,'Create','create_antibiotic',NULL,NULL),(11,3,'Edit','edit_antibiotic',NULL,NULL),(12,3,'Delete','delete_antibiotic',NULL,NULL),(13,4,'View','view_culture_option',NULL,NULL),(14,4,'Create','create_culture_option',NULL,NULL),(15,4,'Edit','edit_culture_option',NULL,NULL),(16,4,'Delete','delete_culture_option',NULL,NULL),(17,5,'View','view_doctor',NULL,NULL),(18,5,'Create','create_doctor',NULL,NULL),(19,5,'Edit','edit_doctor',NULL,NULL),(20,5,'Delete','delete_doctor',NULL,NULL),(21,6,'View','view_group',NULL,NULL),(22,6,'Create','create_group',NULL,NULL),(23,6,'Edit','edit_group',NULL,NULL),(24,6,'Delete','delete_group',NULL,NULL),(25,7,'View','view_owner',NULL,NULL),(26,7,'Create','create_owner',NULL,NULL),(27,7,'Edit','edit_owner',NULL,NULL),(28,7,'Delete','delete_owner',NULL,NULL),(29,8,'View','view_animal',NULL,NULL),(30,8,'Create','create_animal',NULL,NULL),(31,8,'Edit','edit_animal',NULL,NULL),(32,8,'Delete','delete_animal',NULL,NULL),(33,9,'View','view_report',NULL,NULL),(34,9,'Create','create_report',NULL,NULL),(35,9,'Edit','edit_report',NULL,NULL),(36,9,'Delete','delete_report',NULL,NULL),(37,9,'Sign','sign_report',NULL,NULL),(38,10,'View','view_role',NULL,NULL),(39,10,'Create','create_role',NULL,NULL),(40,10,'Edit','edit_role',NULL,NULL),(41,10,'Delete','delete_role',NULL,NULL),(42,11,'View','view_user',NULL,NULL),(43,11,'Create','create_user',NULL,NULL),(44,11,'Edit','edit_user',NULL,NULL),(45,11,'Delete','delete_user',NULL,NULL),(46,12,'View tests prices','view_test_prices',NULL,NULL),(47,12,'update tests prices','update_test_prices',NULL,NULL),(48,12,'View cultures prices','view_culture_prices',NULL,NULL),(49,12,'Update cultures prices','update_culture_prices',NULL,NULL),(50,13,'View','view_accounting_reports',NULL,NULL),(51,13,'Generate','generate_report_accounting',NULL,NULL),(52,14,'View','view_visit',NULL,NULL),(53,14,'Create','create_visit',NULL,NULL),(54,14,'Edit','edit_visit',NULL,NULL),(55,14,'Delete','delete_visit',NULL,NULL),(56,15,'View','view_branch',NULL,NULL),(57,15,'Create','create_branch',NULL,NULL),(58,15,'Edit','edit_branch',NULL,NULL),(59,15,'Delete','delete_branch',NULL,NULL),(60,16,'View','view_contract',NULL,NULL),(61,16,'Create','create_contract',NULL,NULL),(62,16,'Edit','edit_contract',NULL,NULL),(63,16,'Delete','delete_contract',NULL,NULL),(64,17,'View','view_expense_category',NULL,NULL),(65,17,'Create','create_expense_category',NULL,NULL),(66,17,'Edit','edit_expense_category',NULL,NULL),(67,17,'Delete','delete_expense_category',NULL,NULL),(68,18,'View','view_expense',NULL,NULL),(69,18,'Create','create_expense',NULL,NULL),(70,18,'Edit','edit_expense',NULL,NULL),(71,18,'Delete','delete_expense',NULL,NULL),(72,19,'View','view_backup',NULL,NULL),(73,19,'Create','create_backup',NULL,NULL),(74,19,'Delete','delete_backup',NULL,NULL),(75,20,'Update','view_setting',NULL,NULL),(76,21,'View','view_chat',NULL,NULL),(77,22,'View','view_activity_log',NULL,NULL),(78,22,'Clear','clear_activity_log',NULL,NULL),(79,23,'View','view_translation',NULL,NULL),(80,23,'Edit','edit_translation',NULL,NULL);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `permission_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES (1,1,1,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(2,1,2,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(3,1,3,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(4,1,4,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(5,1,5,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(6,1,6,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(7,1,7,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(8,1,8,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(9,1,9,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(10,1,10,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(11,1,11,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(12,1,12,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(13,1,13,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(14,1,14,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(15,1,15,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(16,1,16,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(17,1,17,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(18,1,18,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(19,1,19,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(20,1,20,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(21,1,21,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(22,1,22,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(23,1,23,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(24,1,24,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(25,1,25,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(26,1,26,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(27,1,27,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(28,1,28,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(29,1,29,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(30,1,30,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(31,1,31,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(32,1,32,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(33,1,33,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(34,1,34,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(35,1,35,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(36,1,36,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(37,1,37,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(38,1,38,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(39,1,39,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(40,1,40,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(41,1,41,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(42,1,42,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(43,1,43,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(44,1,44,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(45,1,45,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(46,1,46,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(47,1,47,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(48,1,48,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(49,1,49,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(50,1,50,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(51,1,51,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(52,1,52,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(53,1,53,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(54,1,54,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(55,1,55,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(56,1,56,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(57,1,57,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(58,1,58,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(59,1,59,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(60,1,60,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(61,1,61,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(62,1,62,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(63,1,63,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(64,1,64,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(65,1,65,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(66,1,66,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(67,1,67,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(68,1,68,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(69,1,69,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(70,1,70,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(71,1,71,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(72,1,72,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(73,1,73,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(74,1,74,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(75,1,75,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(76,1,76,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(77,1,77,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(78,1,78,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(79,1,79,'2021-10-16 02:23:57','2021-10-16 02:23:57'),(80,1,80,'2021-10-16 02:23:57','2021-10-16 02:23:57');
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'super_admin','2021-10-16 02:23:57','2021-10-16 02:23:57');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'info','{\"name\":\"Nacional Code\",\"currency\":\"USD\",\"address\":\"Address\",\"phone\":\"+57 3504931577\",\"email\":\"admin@nacionalcode.com\",\"website\":\"https:\\/\\/www.nacionalcode.com\",\"footer\":\"All rights are reserved\",\"facebook\":\"#\",\"twitter\":\"#\",\"instagram\":\"#\",\"youtube\":\"#\",\"socials\":{\"facebook\":\"#\",\"twitter\":\"#\",\"instagram\":\"#\",\"youtube\":\"#\"},\"reports_logo\":\"iVBORw0KGgoAAAANSUhEUgAAAGQAAACHCAYAAADgMvx4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAB7TSURBVHja7J13mFXVuf8\\/+7Q50wvTgKE7dOkqICgWQDGCxB5jid5YMLFgIWqIF6\\/+jCi5mthiidEIifWqgBoUG4oSUUFBUHoZpvdyzpy2f3+863hm5uxTp6K8z7Ofgb3XXmft9V3rrWu9S9N1HT9pmkY3UgEwExgHpADeTv49M+AAvgXeAXZ014e3xABd13+4upFOAZ4BDgB6F1\\/lwIvAOd0JyA8Y9ABAlnUDCKGuFUDCTxmQ13sQGP5r008VkNt6IBj+6x8\\/NUAyw3WI2YSudWKHa+o3IpQb0R2AWLpJbhgK0Pn9YPFk6G0Br1d6pbPIYoZKHR77Ch75zrDIJWoWdyl1FyCT2t44Lgdena9a1AR0tgauQ34CPDwPSl+El\\/cGlZjQHR3TXYDktL1x\\/iAgESgGTF3UiiYgD3452BCQnO7oGFM3AdLc9saWamWq+ZVOzeAyar1DdWy4LwlVlxWww9ba6Nr4Y54hQVz72Z1w4jq4ZILqMK9BpwLUAz7VmeVKPTBbodQN+YAnwJLQgFT1VzcAU4N3Pof7vjFs4\\/fd0TFaN7lOxgNfGj04Pg8GpCqhrprm1SHFCnP7w8+HA06gChg0FO5YA2YbLJsPX2+AXi06Pxk+2A3Ld0F1M5hbfJ7FAmUOeLcoZBvPBl79KblOPotHZf37Cej6dej6THR902v6D1S8Rdfnouu\\/RNcvQ9d\\/i\\/7+nHa5U7rFDukuGQJwVjx8eunX6q1EIGtA4EF634BLUhOWtPTruNt2Wnd1SncCUgKcoPSqqCnFrCSfG1j718CDdx4VNmYLyJy02CVks2JVX3RXp2g9wP2eBjwKzAeSIhV+53Q4tRCoBhqA+deIUH\\/lzzJrbIrpJMPWEpjyBtS7I7bBDawBrgN2d4cvqycB4qc\\/Aota3hjXC345DJqdkGyBOQVQ2BtoVHPbo+aZjmhYVqWBof6mQlkVvLwHql2QmAgrd8EHJUG\\/\\/SJwfnd9eEsMLPQcamh7Y2oO3DQLqFMd7GpRyqdA6dOGAdcDtUqOlELuAFgwVZXvBbxhCEhDT+mEngSIve2NGhdQqbpLb2OPtCWzKptuh4tug+yBsOVtWPlPsVWsUqzcafh2whFAOpocSsNa8in0H6eMmksgYwD87Y\\/Q9\\/D4DNOPBpByYN5FATB+cJLdC4MzhZUdAaSzpWEbN8m4s43LDRrbg6TEj41lmZXKW9\\/CR5Wj\\/u0M0evuxsNm6B1egJiAvcCIfDj1akjJhn1fwqq\\/CUjr\\/wpTL279jqcJvt0k1s4RQDp4ZhwATpwJt7wC9tTAs4lnw93z4bVPYOKTcNKvlWrshfvPhmo39D4CSMdSNdA3BRavCX42dg7c\\/hxcdwEsuxI2vw4FY+CzFfDNPlmC5zsCSMdSLXDNktDPx58PU26C7UWwZjW4VksspIDODc7\\/JLUsD5AODD0lfLkh08UeyQP6ARlqZhwBpIPJh3Ic2sOXS8w4rDr\\/8AXEjPizmmoiyJl9UvYIIF0AiANY\\/3R4K\\/Gbj4S1HQGkCygHeOFJKN1m\\/HzFQtjbKIL8CCBdQEmqtYumwaY3Wz97fiE896DYGoe5DDl81F4vkAuUVsGSM2DSVEjJggPfwJZ9kI1EC31HAOla9TcHCVR9ul5AshMIUh3mYBx+gPg73ULrhZ46Pxr68cRDjgByhI4AcgSQI3QEkCOA9Cj96af42z0WkMZu\\/G3XEUACdBRwO\\/DrbmzDmcC9SFqPnywgU4H\\/Q3KM3AMMCRq2ncBImo0zqOQCvwO+Aj4CTv8pAXIy8C7wCbJHJCTZtQ72JZii2qIwHXgT+JxuyH\\/SlYCMA14B1iLJZiLS9WORjQId5RpxwOWjIcMWVelJwEuqvSd3VSd1xXYEE7AE+H00hXMSYVYB3DIaxhYgkcKOapYPSIdDlXDXV\\/DmATgQ\\/YrGJ5HtEtUd3UFduT9kBvCUkXxoS7P7wYKRMLO3hMbxEFiP25HN8iFb3xJAr4W1pfDXbfBydNt0qoAFwAuHIyD3KkEZkqwaXD0aLi+EcX2QLQNNdN0OcSuQLCDtLIFnd8OjX0NVZCX4GeDywwWQXNXgOeEKXTECbh8Lg\\/sh25wbCWzY7ErSFVNNEnCqSuCPX8NfNoMzvOz6EvglsK0nAzJcaU9ZoQrM7AsPToORBWom1HcDCOHAUcAcKoVb1sOKXRHfOBV4rycCMgfZaG+4GynDCg9Oh0tHIqtIaglsI+hJ5O+ONJk5b+2Eaz+APeH9CFcqod9jADkvnKA7pTc8czL0K0C2nbno+W5NXQ2cXtBQCVd\\/BMt3hn3jFuCBngDIGcCqUA8Xj4e7TlTyoZbDz7+sdvOSCE9sgKvWhS39W+Dh7gTkTOCNUA9fOAXOm6CAcHL4Ovt15THIgnXfw5mrodYT2p4F\\/twdgIwEtho9SDTBmjNh2lDForpDe+oMUDQgG\\/YegumvwkFnWHn6VlcCkgbsx2DhZooZPjoLxg8BytohuL0t+Hh7wfSne\\/KoOq2qXj1OFpYNpZVwwivwfWhL\\/yhgV1cB8ikw2chHsv08KOyP7IrVYuw0Tb3nVOqnWdknughXkogt37VZ1VWGLKJLV79Rp+7nIuu6vHGA0gsaaqFwOZQYG7JFyKYIvbMBeQC4yejBx2fC8UOBihjBMCFOxCJg0iiYdhEMmgiWBCjbAZvXwLqXRBb5N+BE+kwLcEjNhtkXw6S50O9oadihbfDZi\\/DvFQJaVpygZMGBcjjmZSg1BmWVkrOdBsh0JF4QRC+dBOcch+QeiYc\\/HwLOuhgWPGdcZtdGePgy2LJVQNHCgGJBNocO7A03LIdRJxmX2\\/Ay3HWu7D1JJ\\/ZArg\\/Ih292wpjQqc5+rfx5HQ6IXTnXEts++ON4WDRTsZtY+bIZCVHNnwc3vBa5\\/NIz4Y1VMCxEB1qAfcDwQlj6Gdizwte36RX43TmyEtIS52DKhbe\\/hNPXhiw1ULUqIiCxKKIPGYFxYi4sOhGoIb6lAlVAYRYsWB5d+VtXwswTRaUwG7C+ciDTAvd9EhkMkGQDZ54p7DIetVwTFn3aRI2FY5PCOSOj5t7R0CjlHmhF6TZYNUcB4YxDG9KQ6MI5N4MtOfr3Fr8NuTYBU2ujmdUCC5+CxBiyvM6\\/V4w\\/V5yAOAFPOsuumMCEfENQTkLygXUYIK8Y3Vw+DVJy1eyIZ3S5EFYx7uexvWeyw9UPiY3TsmMOATMnw3GXxlZfn1EwbXrsmRY19Q12MyQPAovG6osGhyq9vKMAmYVw7FY0twDOGKMMv3gt8CagXz7kD4v93elXw\\/HDoVR1jJ9dzr0zvraMOE00vVhtJQ3IHwIJiVBcR35hGn86pY+hvays+HYDEuQGMGnwz5NaGFvxUjOQXRj\\/+7Ovl72HKNtiaCqMjjN\\/Zf4w8VNHq5T41Pfn94eUHHCp\\/OhVzdx4RgFHZRk6ve8hQpKPSID8wmh23DwSkvJpf7zbCyRlxP\\/+hLNls45TyY4pl8VfV1qOjOFo7BFd2U3ZeZDZT4Gh+qLJA0kWHpttmKArGVjYHkCCpliSBe6cSMetM2xPDCY1B4aMFsXABhzdjuyuloTo3Cm6X\\/blQs5gcDtB97VmH2VOTj0uh+n9U4xquDJeQAqBY9ve\\/MNYNTsaO8DHZAIcde2rY+w8yYWViaT1i5c8zZGdoD7FonPyIGcIeNzg9QS\\/5PKCzcSDMw1lSW8ll2MG5BYj2fHbkUgHaBG0D10J7TpCx8ttQPX+9gHSf5yKiZshLS\\/+eurLQ4cI\\/Ak4XUBOb8gvBK8LvG7jGW7SoKKZCSMzGJFtmH1iSayA2IEg3fHiIZCUqzo6nIOwVBloaTYoyIPMJOHxBxTvNbfQO0r3QF1Z\\/B2ZlCEWtiUBEpLir6d0lygZphYehAbgoPLNuYD0JEn5VHVQfW+Y8ez2gd3MXSfkGz2drKx3Q0eDEc0hkCP6B7pjNIGVhJoBGF5lC0ydAmfcBMOnQ2q2pMTYtRHWPQdrlgs4+YhWU6LDzvUw4az4OtJsVWqvRzorXtq3ITCgfH5fWBrM\\/RWMnAE5A+R0gJ3r4dPlULxN2JaOseDRgFoX50zsRf47hyipD7I6z0ZOqItqhgRZlcflQGG\\/COzqIHD2ZbBkPRx7NqTlyihKzoIxs+Da52HJashID3him4HN7TiEwOWQr3C6oLEmTnuoBj5fLS5+t\\/I6zZ4Hf9oJFz8IE8+C\\/uNhwAQ45Tdw8zsweraAYgozSxxe6JXIBaMyo+rjcIAEuUfPG6jmjDdELQeAY0bC1RHcNuPmwMNbhI0dRNTWd1ZAbUl8nVlbIoK2Fqgpiq+Oz5bD7mZhoQeBS6+FW14TVdiQoafANS\\/AqFlQugNMITLeWKzgaOLn\\/Q2fTsXgFB9TCP4WpESf3kfxUaPZ4UR8QTe+El0HpBfA0k8gSZM6D3lhZZwW9jerA\\/x+29r46nj3z9L+PcC8eXBZlOsULn1cwGluDFblzVaxT0pLOT5fIz3BZMTU5kUDyM\\/a3ihIghE5quONqAI4cRbkDY\\/BfzQOFjwgZyP0AV59Aqr2xtaRPi988bqovMnAew\\/HDsanT8Gn6jCdodlw3YvRv5ueD5POgcp9AQFvMsvlqIWGCmj2YcpOYM4ge1ScyAiQcUF+q\\/7IAmVPGP18TBxC+ZSFMG2YjO5m4M7pMbKaZ2G3W8DoBWwqhi2ro3+\\/rhju\\/jVkmcR1fctLYLLF1obJv4CEFPC5wWwRI7G+UgAxmaWLzRpnDUk0entMNIAMbXtjZh9CR+i8il31Gxcfu7jwfvFH5QNbDsID86J0uzjhmdvFM+TXjpKAxxZE55By1sOSaZBsg4HZMHkmFM6Ivf2Dj4N+Y4VtuRxiz7ibwGQJ8PdmH5NyrUZvH0WbhFJtAckFgvzHYzIJHStwA2kaZMaZXH3MmTA8U1z4A4HVb8A9s6GuJLzJ\\/N8nw65SEYv+GHsesG0\\/3BVhf03FXrj\\/VCjfA5MmQWMjDJsVv6aX1Q9qimWJo9ejwGipCfoYlGEmP9lsZO8NDwfIUNrE4XITYVAqoV3TXsDeTqNszBmBIyYGAR+sgWuPgtXLoLastczY9BbcOBw2fCplPW3aMghY9wEsHC5l3c2trfH3H4P7ToKy3TDsWKivlxzAw2fE336LFWodIkeMNC4PaElmCjMMzb6h4QzDoHTDg1NAs4cBRAN8vtYOtlipcBqYng9wmgFAdSP85WZ49XYoGAm2JBnZuw9Jx\\/fHOGTsQxZBbPkO7pgDIwbCwAnC30t3QtkuSOklfi9XMzRWwaBJ0G9M+xyT4Rylug5WjYIUcyjfVkhAgrxhA1NaGHCGljLgcEFTLaTmxvdBfUaKYPaq+rzIKpA0oMEFX22SjvavrbK0sYd8BNLBmgCbDYangdUO3mbY8Yl0lj0FcgbJv32egCzJbUdMBuUlMEVwSlo0+qcZAtInHCBBJkyGLYIL0qIciNUHIS\\/OD+s9DLJtUOcKnELlny1JtD6ZSldg+EHQFIiJiZCYJr6thGSwKG3J6w52qbQ8ItDnDW0ARksNVZFXrGiQm2TYkTnhZEiQIZFuI\\/waKL9RdiD+M+pIzYWM3gHFwS+k\\/VE5d4vLB1htgTbZrZCaKTl9NU1Ym9kicQq3M7J\\/y\\/9Oe6j6AFgjhJZ8OhkJhmXyws2QoDmV7mcPLd3nmoGHd\\/tamHl9\\/B\\/lcgY63eQf+SaxeC02sCaANUn+1hyCIcfApHNhwHg56bN8N2z\\/AL5+U9TPnMEKjGhisu3Yd125T1ZCRhH5TLVqEd1XFgMR3YoSE22QZBM54fWI8G65lNOneP1\\/3hQ5khRH4tzqItHde6dBSjJY7AKCxSqAmCyivWgaFG0Vz\\/Alj7U+IWHIZDHSdn0GL9wsMzZ\\/aBQeYA2c7Qh\\/fvkalFZD\\/37hFRsdUm2mUGpR9DNES0yTCJlFB011is8Hulc+1qcY+v49sO5pmL0w9o+qOiCd2zsfNJvi8bp8oM+nBLAO+76CaZfCr8IkVB4yGW5bB385C75+SwJYXndrFoUWcHVomsyueGnT6+KTi0LLtJiICEjbIkGL6zWvCxz1crmawONSfDdRpmlaHmT0gcFD4dPnVUgzRiraCo3Vcgqx2ynhVE+LGamZROUdODE8GC07fcFLou6W7pDZZrIEDDavG5oboEnlANjyduQ05kZ0YDN8\\/T5kRqcUNHsNWaMrHCA1wTNNjSafF5qb5CPqy6GmRKzT2hKorwBzorCJt+6N\\/cO+XSuC1fCAZE3cEh43XPl8DLaBTVzkALWl4HEqh1+lXE01Aoo9FQ4cgk1vxN7uV+8Q2WqxRzFIoMFtCEhTOECCVhxUOxX70DQJxvzAz5X+7WqSj6svF4NrxR\\/gixgCTmU74dt3xf3g95S2vKxWKNoOpy2MXa3uNQCu+Bvs2yeuGGe9APuDV1b5mxKB9c\\/FVve6p2HdasjvE12kUtOobTZka46YWFaZwxtiF5QWcBWYLPLckgBJdnj4PNi8KgrlxguP\\/SJgK7id4upwNwvb8nng4HYYNg3OuC0+Hj9hPpx+GeyvEHXZZGpjUevQKx++XAsbX46uzh3r4G9XQXaqyNVoSIMKhy9mlhW02qDC4YtyM4sSbJl5YDbLtoF\\/\\/2\\/o4vVl8MBpsOVzYRsNFeLG+OGqFudfbR1c9lfRtuKlSx6HoYVQdtDY12SyQmoKPHw+fP9R+Lo2r4Z7ZgioqVnRuYw0sUMONhh2ZHU4QL5rW3p\\/nVcyiZmjXITl9YiRl5EJzyyExeNg7SNw6FuRN0Vb4a374ffjYPO7MECpi5qmLr9to0NJHVy6VFwr7SFLAlz\\/Gjh9wrba+px0H6T1EjX73pNh1b3BR\\/CV7YS\\/Xwn3\\/wxsCdCrb\\/QKjKaBW2d3jSEg37cq2mbDznDa5O7ISDBRelU+tmSzfFC05P\\/o6kPQ7JOFDbZkEaS1dZCSJCtSjPiv2QwH9sP4GbDofTqMVt0Nzy6G\\/gXGCoTZIjOzpg4GDpODxeyp4hbauxEqqyA7WxSQWFa42DTwwVFPlrCrJgjE2bqurwkFSCKyqqpV0GTrpXmMHJgAdfEss1HratxKJpgs4vQL5Y\\/RTNBUB4118MB37Xf8taUlk2DXF5Db37hTNU3AaqwGR5Ny1QDJmRIZ1KPZ4NiGks1UlrvJfaIEX\\/BAGKrr+o5QLMuBwdarrZVuSIh3z4HSCKx2+SCrPYK7wgfltfBfjxuDUblPLPEnLpbVIm3tguevhWevFvvDiC5+RL7S7QztKkcBkN0XcvtK8M2WpORFHG4Wu8bmSrcRGHXIXrCQMgRgc9sbK3c5waN3\\/uZ\\/swWKimD8FDjBYE1y6Q64eyq8vUxU6ycvgScuEjvl0+Vw73T48En46ClYcgxsWhlcx+DjYN4CKC4LvXyno0nTWLXHcABsbhvYMNr0eQVtdo1m2U1UXNMbLcEk8qCzqLkJmhrgns3QZ0Tw8+d\\/IwrCwIkyknWf+MEGjJfAE5rypWnigdV1uO2j4A1BLgfcWCCqdUpmCIO0g8gqysqQx4vZHZyPYymwKNKmzzfbzssqp4+NxW5I6sRkJSYzlFTD3FuNwfC6xJeVrXi\\/X93MKoDi7aJJJaYp\\/5pHDM36cnjvUQMhmwhzb4fyxs6f9Ylm9pa5jcAAWBPW9auoGMlf24re2ucUbUHvnClNXQXkZ8Lpi4zL1JSI28aSGMzzk7PEVdLSJvB5RatrqjWub9ZCGDkKqkrbt0clkvhMNPG6MbuqAt6PBhCQ1Kit6F\\/fOaDBJ1OwM6i6Cebe0dql3nZU+9lUVCCbwNUo8fJQg2DWDVDnptOmiQVw+li+zXC7wHsYrAoIBUhQMrJtVW427HBAmrnjZ0lDJQwcIKM2FKXmSHyjxL+WVguvHBRvF1lzwn+FLjf5IuiXJ7\\/fGbMjxcLuvU4+LzVcQ\\/WSIecOUd0XSH6F1ir8f+plM0pHihLNBFUOOO7CyKzjFw\\/BkONElriagtc\\/aZqAVfStnLV+xd9bqNkhZt20y6GqKfwq9ri+C0gwce9Gw3RBbuD1WAABeDBIjuxxUrG\\/WfJ1d9Qs8bnE2zoxir3q2QPhjk\\/gvKXiC6s+GPBxaSZxUu77CkacBIs\\/g76jItd56nWQnSYulQ6dHWYaD7l47ltDdvU0IdbxhANkhdHN\\/9lQD3ZTx7Hd2goYOR0GHRO9NnbaTXDVCmFNFXskzu6sFzY16wa4YZUshI6G0vNhxAyorenYGZJi5n831uPyGY7ckBnnwgFSA\\/wrqKZNDRzY6YCMDpoljV4onB77e0efBos+EFV3538kWHbZk3DBstjrGj5DjVetY2ZHmpnGomaWbDDc0Po5YXL9RmKchpsTb11XK7PE1AGtNyHe4Xgodwj87kNZ6H3p4zDtsvjqGTgJklssnmuv7Egxc+fHdXiMFcI\\/hGUAEarfDvzTSAXetrUJelnBp7f\\/A6yJ8b+fWQD\\/8yVMuSj+OvqOgux+wRtv4pkdmRbKdjtZ9qWhMN8EvN0eQAAWG92c81qluOOT2qMGaxL8ctTSrZScBb1HykKO9pBN4jnzXw+pRkdckhMNILswyNq8t87D\\/3unRmZJe1ivXYPv3qPbSW+nj84H5Np4aX0964sN7Y6PjSzzoCEaQ0a5aiAjaA5eksfY4YlQ6hIbJeaO8EBpKSz5GAqPj\\/39yv1Q8p1E73oPl8XUMRumFbBomEQp41lW6tOhl5WDxS6OeqIk1HKffCTWFNwFcWaUu9HQJfRSOTT6ROuKZ5CZbGAzwTNXxvbe3o3wyPlwx9Fw3yxYOgd+NwKe+03sbXh7mUQDE1LikxtqI87pL1SEAuO+UGC0Z4YArAemtL15xgA7q67MhwYvOHyxszCzCYoPwKBxsHBV5N1Yby6FfyxS6WMzxOLW1JLQolo4dhrcsS66337\\/MXh6AWTlBFbMxwKGVYNcG7euKOP+rwwFeSmyqzlkuLU9WUkz1A8Etfz2Sancc342lLvBFWswS635OrQfcvvA6TfD8ZfIOq9WllExrLwbVj4KvVIlqtcqDKsWSRQdhNFT4bz7YOg045+s2AP\\/fghWPgSZaZCcEVucXEcWfuRbeeytaha8F9KwPBrYEraqdubt\\/Rmw0ujB\\/dPTuflnWQJKPBFGs0Xc7HXNUFAgW477j5NnRVth\\/T+gtATy8mQ0+3zG4JpNULwfLBpMuRDGz5M4imaGqv2w\\/UNY\\/zxUVEN+rvi7Yk3LoYkQf\\/mTOs5dGVKrugn4U0RsOyCzdcjjjJ6elcnlp2XCIVd8oPjb0FgD9Q2tR2R6qhrJUSw0MJnB7YBKlUgxMUHqdjiFeWRmQGJqCFAjzAwTUJDAhxvqmfFCyESNLwPnRlVlByXjXwPMNHrw6MxMrjk1A6rccm5Qeyx6f\\/vaE0TSdbHCdV1moRZng\\/wyI8fKy+vrOP+1ylB6zHfIHnRXVwICElkcZ\\/TgrqlpLD4jC5q8Etg63M+l9iHHPmRa+PsHtfzqrapQJcuRU+nqox8vHQdIsgLFcPHUFaOTeeq8bGFblZ4A7z3swNBFrbebWLKyiv9eHzILXqMS4ntim8Ade8JOHrAR2YwcRCf0sfHk3F4MHWiHCnfXLCfqMOtdyYscK5Wlbq5YWcXruxyhSjcjiXs2xc5RO\\/4MqmzlFhht9NAC\\/GNuLy6YkiY5pPwrILUezqJSzZBq5v3NjVz4fxWUOkIqAKVKnn4Tn4jrnFPaLMipMqeGKvDzoYk8MiuT\\/P4JUOkW56RJ63mzwqpBtpWmMjfXvVvN05vDeoG3AydisHOguwHx07+A80M9TLVo3Hp8Gr+fni4jsNojwGg9AAibJrLCo\\/PEZ\\/Xc9WEtRY1h7RP\\/Ud9N7frpLjh69Wbg\\/nAFJuXZ+O2xqVw4PBFrpiXgdumOsw0TTDI4Gr28ut3Bo180sHafM9Jb9wO3dshY6KKzcCcCr4US9n7qm2pm8dQ0LhqVTEqWRYZqnRfceueCYNEEBLOGp8bD6zuc3PlJLVvLIyaAbwQuIMxRgT0VEL9afA9RJKHPsps4\\/Sg75xYmMW9oIqSrwFezT1iaR48\\/EKYpv1OCKRB6bvTx3k4H\\/\\/rOwZu7HBTVR+U6WYEc4X2wQ7llFwLip1OAu5DEjxFpaJaVUwYmMDnPxrH5VoZnW8XFbVHtc\\/tUrhM9kIIDAhkg\\/GvHLJr8262Dw8feKg8bSlysL3bx8YFmviyN+sCQb1X7X+iMzukOQPx0PXAbbfJ7RKIhmRaOzrZyTK6VozKtDE43k5mgkWjRSLJoJFlNkgffrdPo8eH0QJ3bx946LzurPXxe5mZLhZtvK2I9j4JG5GShOzpVn2i5+l7X9R+uLiI7clDWHgJJOuK6LCZNT7Fpem6SWc9LMutpNpNuMWl6e+tFFkLfouyrzlfwWmLQDYC0tFuuAj7sgA7sqGuj0pwyu1Tj7iGAtKTRSNxgTzeAUIIs7ZzSbSZQCwy6WoZEQ9OUT2iGckfYOuE33ke2A3wGrCN0vrwuA6S7hHo8jsuJwAgkZ+kgJGtqPrJE2x7G0edEXOG7kNT6e5A94V+p\\/\\/ccb81hBEhLylRG5hD1N1ldKerSlFbUoP42Kna0Q9kN5T31w1pi8P8HADi+QzRraJWvAAAAAElFTkSuQmCC\"}',NULL,'2021-10-16 03:37:44'),(2,'reports','{\"show_header\":true,\"show_footer\":true,\"show_signature\":true,\"margin-top\":\"0\",\"margin-right\":\"20\",\"margin-bottom\":\"20\",\"margin-left\":\"20\",\"content-margin-top\":\"230\",\"content-margin-bottom\":\"220\",\"footer\":\"footer here\",\"branch_name\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\"},\"branch_info\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\"},\"owner_title\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\"},\"owner_data\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\"},\"test_title\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\"},\"test_name\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\"},\"test_head\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\"},\"result\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\"},\"unit\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\"},\"reference_range\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\"},\"status\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\"},\"comment\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\"},\"signature\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\"},\"antibiotic_name\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\"},\"sensitivity\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\"},\"commercial_name\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\"},\"report_footer\":{\"color\":\"#000000\",\"font-size\":\"12\",\"font-family\":\"sans-serif\",\"text-align\":\"center\"}}',NULL,NULL),(3,'emails','{\"host\":\"\",\"port\":\"\",\"username\":\"\",\"password\":\"\",\"encryption\":\"\",\"from_address\":\"\",\"from_name\":\"\",\"header_color\":\"#c43e00\",\"footer_color\":\"#363636\",\"owner_code\":{\"active\":false,\"subject\":\"Owner code\",\"body\":\"Welcome , {owner_name}<br>Your code is : {owner_code}\"},\"reset_password\":{\"active\":false,\"subject\":\"Reset your passwor\",\"body\":\"Reset your password\"},\"receipt\":{\"active\":false,\"subject\":\"Order receipt\",\"body\":\"Welcome {owner_name},<br> your receipt is attached\"},\"report\":{\"active\":false,\"subject\":\"Medical report\",\"body\":\"welcome , {owner_name}<br>you report is attached\"}}',NULL,NULL),(4,'sms','{\"sid\":\"\",\"token\":\"\",\"from\":\"\",\"owner_code\":{\"active\":false,\"message\":\"welcome {owner_name} , your  code is {owner_code}\"},\"tests_notification\":{\"active\":false,\"message\":\"welcome {owner_name} , your tests are ready now .. you can check tests by using your code : {owner_code}\"}}',NULL,NULL),(5,'whatsapp','{\"receipt\":{\"active\":false,\"message\":\"welcome {owner_name} , receipt link is {receipt_link}\"},\"report\":{\"active\":false,\"message\":\"welcome {owner_name} , tests report link is {report_link}\"}}',NULL,NULL),(6,'api_keys','{\"google_map\":\"\"}',NULL,NULL);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `test_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_options` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_id` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `test_options` WRITE;
/*!40000 ALTER TABLE `test_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_options` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shortcut` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sample_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_range` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `separated` tinyint(1) NOT NULL DEFAULT 0,
  `price` double NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `title` tinyint(1) DEFAULT 0,
  `precautions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tests` WRITE;
/*!40000 ALTER TABLE `tests` DISABLE KEYS */;
INSERT INTO `tests` VALUES (1,0,'Complete Blood Count','CBC','blood',NULL,NULL,'',0,30,0,0,NULL,NULL),(2,1,'hgb-hemoglobin',NULL,'blood','g/dl','','text',1,0,0,0,NULL,NULL),(3,1,'hct-hematocrit',NULL,'blood','%','','text',0,0,0,0,NULL,NULL),(4,1,'RBC-Erythrocytes',NULL,'blood','million/µl','','text',0,0,0,0,NULL,NULL),(5,1,'MCV',NULL,'blood','fl','','text',0,0,0,0,NULL,NULL),(6,1,'MCH',NULL,'blood','pg','','text',0,0,0,0,NULL,NULL),(7,1,'MCHC',NULL,'blood','g/dl','','text',0,0,0,0,NULL,NULL),(8,1,'RDW-CV',NULL,'blood','%','','text',0,0,0,0,NULL,NULL),(9,1,'pit-platelet',NULL,'blood','10^3/µ','','text',0,0,0,0,NULL,NULL),(10,1,'MPV',NULL,'blood','fl','','text',0,0,0,0,NULL,NULL),(11,1,'PCT-PLATELETCRIT',NULL,'blood','%','','text',0,0,0,0,NULL,NULL),(12,1,'PDW',NULL,'blood','%','','text',0,0,0,0,NULL,NULL);
/*!40000 ALTER TABLE `tests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (1,1,1,'2021-10-16 02:23:57','2021-10-16 02:23:57');
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `signature` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Super Admin','admin@extremelab.tech',NULL,'$2y$10$w2sOP/cco7mLE.Ly0lTafO1zwk9ccIIVR8MjUY0W9XnRDAKgACE0y',NULL,'C3NehLogX6hMvH24j9Bliti40ZaZ8M70','2021-10-16 02:23:57','2021-10-16 02:23:57',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `visits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `animal_id` int(11) DEFAULT NULL,
  `lat` double(8,2) DEFAULT NULL,
  `lng` double(8,2) DEFAULT NULL,
  `zoom_level` int(11) DEFAULT NULL,
  `visit_date` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attach` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `read` tinyint(1) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `visits` WRITE;
/*!40000 ALTER TABLE `visits` DISABLE KEYS */;
/*!40000 ALTER TABLE `visits` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

